# Overview

[https://docs.holybro.com/~gitbook/image?url=https%3A%2F%2F2367252986-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FLIgtGDAvVGkCKGOJb1bR%252Fuploads%252Fi1uXvLwuRuaS2QxlHww7%252FDroneCAN%2520M8N.jpg%3Falt%3Dmedia%26token%3Df4e08638-fe93-4efd-83cd-314d318beada&width=768&dpr=4&quality=100&sign=5d4d0ee&sv=2](https://docs.holybro.com/~gitbook/image?url=https%3A%2F%2F2367252986-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FLIgtGDAvVGkCKGOJb1bR%252Fuploads%252Fi1uXvLwuRuaS2QxlHww7%252FDroneCAN%2520M8N.jpg%3Falt%3Dmedia%26token%3Df4e08638-fe93-4efd-83cd-314d318beada&width=768&dpr=4&quality=100&sign=5d4d0ee&sv=2)

[https://docs.holybro.com/~gitbook/image?url=https%3A%2F%2F2367252986-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FLIgtGDAvVGkCKGOJb1bR%252Fuploads%252FEqrCvyiLuVBMpQZr9joI%252FM9N.jpg%3Falt%3Dmedia%26token%3D5a8ccd12-e2bb-41bf-be61-801e5254223a&width=768&dpr=4&quality=100&sign=b753fe0f&sv=2](https://docs.holybro.com/~gitbook/image?url=https%3A%2F%2F2367252986-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FLIgtGDAvVGkCKGOJb1bR%252Fuploads%252FEqrCvyiLuVBMpQZr9joI%252FM9N.jpg%3Falt%3Dmedia%26token%3D5a8ccd12-e2bb-41bf-be61-801e5254223a&width=768&dpr=4&quality=100&sign=b753fe0f&sv=2)

**Descriptions：**

The Holybro DroneCAN GPS has an UBLOX M8N or M9N module, BMM150 compass, tri-colored LED indicator. It has adopted the DroneCAN protocol for communication. It is better in dealing with electromagnetic interference compare to serial connection, making it more reliable. It does not occupy any serial port of the flight controller, and different CAN devices can be connected to the same CAN bus via a CAN splitter board.

### **Features and Specifications:**

**DroneCAN M8N & M9N**

GNSS Receiver

Ublox NEO M8N

Number of Concurrent GNSS

M8N - Up to 3 GNSS
M9N - Up to 4 GNSS

Processor

STM32G4 (170MHz, 512K FLASH)

Compass

BMM150 or IST8310

Frequency Band

GPS: L1C/A
GLONASS: L10F
Beidou: B1I
Galileo: E1B/C

GNSS Augmentation System

SBAS: WAAS, EGNOS, MSAS, QZSS

Navigation Update

5Hz Default(10Hz MAX)

Navigation sensitivity

–167 dBm

Cold starts

~ 26s

Accuracy

2.5m

Speed Accuracy

0.05 m/s

Max # of Satellites

22+

Default CAN BUS data rate

1MHz

Communication Protocol

DroneCAN @ 1 Mbit/s

Supports Autopilot FW

PX4, Ardupilot

Port Type

GHR-04V-S

Antenna

25 x 25 x 4 mm ceramic patch antenna

Voltage

4.7-5.2V

Power consumption

Less than 200mA @ 5V

Temperature

- 40~80C

Size

Diameter: 54mm
Thickness: 14.5mm

Weight

36g

Cable Length

26cm

Other

- LNA MAX2659ELT+ RF Amplifier
- Rechargeable Farah capacitance
- Low noise 3.3V regulator
- 26cm cable included