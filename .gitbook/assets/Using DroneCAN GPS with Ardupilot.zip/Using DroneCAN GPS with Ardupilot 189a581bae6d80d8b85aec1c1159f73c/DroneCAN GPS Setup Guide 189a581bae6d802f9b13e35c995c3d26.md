# DroneCAN GPS Setup Guide

## **Using Ardupilot Firmware：**

### **Using one DroneCAN GPS：**

Connect the 4 pin CAN cable connector to CAN1 or CAN2 port on the flight controller.

Power the flight controller and connect it to Mission Planner. Go to "Config/Tuning > Full Parameter List" and modify the following parameters:

**CAN_D1_PROTOCOL: 1** set virtual driver of CAN1 to DRONECAN

**CAN_D2_PROTOCOL: 1** set virtual driver of CAN 2 to DRONECAN

**CAN_P1_DRIVER: 1** set this parameter to enable CAN 1 bus

**CAN_P2_DRIVER: 1** set this parameter to enable CAN 2 bus

**GPS_TYPE: 9** set the communication protal type of GPS 1 to DRONECAN

**NTF_LED_TYPES: 231** Set to DRONECAN for LED type

There is no external safety switch. Set BRD_SAFETYENABLE as 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller.

### **Using two DroneCAN GPS**

As the document is written，The firmware used for flight control is ArduCopter 4.1.5, which automatically allocate 2 node ID for the GPSs，you can perform following operation directly.

Connect two CAN cable to the CAN1 and CAN 2 port of the flight controller

Power up flight controller and connect to Mission Planner. Go to "Config/Tuning > Full Parameter List" and modify the following parameters:

**CAN_D1_PROTOCOL: 1** set virtual driver of CAN1 to DRONECAN

**CAN_D2_PROTOCOL: 1** set virtual driver of CAN 2 to DRONECAN

**CAN_P1_DRIVER: 1** set this parameter to enable CAN 1 bus

**CAN_P2_DRIVER: 1** set this parameter to enable CAN 2 bus

**GPS_TYPE: 9** set the communication protocol type of GPS 1 to DRONECAN

**GPS_TYPE2：9** set the communication protocol type of GPS 2 to DRONECAN

**NTF_LED_TYPES: 231** Set to DRONECAN for LED type

There is no external safety switch on the DroneCAN GPS. You can set BRD_SAFETYENABLE to 0 to disable safety switch, or connect an physical external safety switch

Click "Write Params" when done. CAN functions will be available after rebooting the flight controller.

## **Using PX4 firmware**

Load PX4 firmware into the autopilot. Connect the 4pin CAN connector from the DroneCAN GPS to CAN1 or CAN2 port on flight control.

Connect to the flight control and set the parameter "UAVCAN_ENABLE" to "Sensor Automatic Config".